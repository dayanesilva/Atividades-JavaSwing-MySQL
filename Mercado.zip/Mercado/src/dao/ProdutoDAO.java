package dao;
import java.sql.Connection;
import model.Produto;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ProdutoDAO {
    
    private Connection conn;
    private PreparedStatement stnt;
    private Statement st;
    private ResultSet rs;
    private ArrayList<Produto> lista = new ArrayList<Produto>();
    
    public ProdutoDAO(){
        conn = new ConnectionFactory().getConexao();
    }
    
    public void inserir(Produto produto){
        String sql = "INSERT INTO produto (descr_produto, preco_produto) VALUES (?,?)";
        try{
            stnt = conn.prepareStatement(sql);
            stnt.setString(1, produto.getDescr_produto());
            stnt.setDouble(2, produto.getPreco_produto());
            stnt.execute();
            stnt.close();
        } catch(Exception erro){
            throw new RuntimeException("Erro 2:" +erro);
        }
    }
    public void alterar(Produto produto){
        String sql = "UPDATE produto SET decr_produto = ?, preco_produto = ) WHERE cod_produto = ?";
        try{
            stnt = conn.prepareStatement(sql);
            stnt.setString(1, produto.getDescr_produto());
            stnt.setDouble(2, produto.getPreco_produto());
            stnt.setInt(3, produto.getCod_produto());
            stnt.execute();
            stnt.close();
        } catch(Exception erro){
            throw new RuntimeException("Erro 3:" +erro);
        }
    }
    public void excluir(int valor){
        String sql = "DELETE FROM produto WHERE cod_produto = " +valor;
        try{
            st = conn.createStatement();
            st.execute(sql);
            st.close();
        } catch(Exception erro){
            throw new RuntimeException("Erro 4:" +erro);
        }
    }
    
    public ArrayList<Produto> listarTodos(){
        String sql = "SELECT * FROM produto";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Produto produto = new Produto();
                produto.setCod_produto(rs.getInt("cod_produto"));
                produto.setDescr_produto(rs.getString("descr_produto"));
                produto.setPreco_produto(rs.getDouble("preco_produto"));
                lista.add(produto);
            }
        } catch(Exception erro){
            throw new RuntimeException("Erro 5:" +erro);
        }
        return lista;
    }
    
    public ArrayList<Produto> listarTodosDescricao(String valor){
        String sql = "SELECT * FROM produto WHERE desc_produto LINK '%"+valor+"%' ";
        try{
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next()){
                Produto produto = new Produto();
                produto.setCod_produto(rs.getInt("cod_produto"));
                produto.setDescr_produto(rs.getString("descr_produto"));
                produto.setPreco_produto(rs.getDouble("preco_produto"));
                lista.add(produto);
            }
        } catch(Exception erro){
            throw new RuntimeException("Erro 6:" +erro);
        }
        return lista;
    }
}
