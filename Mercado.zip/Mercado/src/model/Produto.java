package model;

public class Produto {
    
    private int cod_produto;
    private String descr_produto;
    private double preco_produto;

    public int getCod_produto() {
        return cod_produto;
    }

    public void setCod_produto(int cod_produto) {
        this.cod_produto = cod_produto;
    }

    public String getDescr_produto() {
        return descr_produto;
    }

    public void setDescr_produto(String descr_produto) {
        this.descr_produto = descr_produto;
    }

    public double getPreco_produto() {
        return preco_produto;
    }

    public void setPreco_produto(double preco_produto) {
        this.preco_produto = preco_produto;
    }
    
    
}
